AUTHOR Derek Reynolds <derekr@me.com>

This project structure can be dropped in to most environments and work. It includes sample template components and sample config file.